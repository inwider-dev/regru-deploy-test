import importlib.util
from pathlib import Path
import unittest

MODULE = Path(__file__).resolve().parents[1] / 'src' / 'semantic_inventory.py'


def load_module(test):
    test.assertTrue(MODULE.exists(), 'Нужен модуль проверки семантики')
    spec = importlib.util.spec_from_file_location('semantic_inventory', MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class InventoryTest(unittest.TestCase):
    def test_unknown_scope_has_no_publishable_demand_total(self):
        module = load_module(self)
        source = {'scope': {}, 'topics': [
            {'id': 1, 'query': 'ремонт квартиры', 'volume': 714279},
            {'id': 2, 'query': 'ремонт квартир под ключ', 'volume': 38800},
        ]}
        result = module.audit(source)
        self.assertIsNone(result['demand']['unique_total'])
        self.assertEqual(result['demand']['status'], 'unverified_scope')
        self.assertEqual(result['counts']['topics'], 2)
        self.assertEqual(result['counts']['ready'], 0)


    def test_scoped_queries_produce_bounds_not_a_naive_total(self):
        module = load_module(self)
        source = {'scope': self.scope(), 'topics': [
            {'id': 1, 'query': 'ремонт квартиры', 'volume': 1000},
            {'id': 2, 'query': 'ремонт квартиры под ключ', 'volume': 100},
        ]}
        demand = module.audit(source)['demand']
        self.assertEqual(demand.get('lower_bound'), 1000)
        self.assertEqual(demand.get('upper_bound'), 1100)
        self.assertIsNone(demand['unique_total'])

    def test_verified_subset_does_not_remove_the_topic(self):
        module = load_module(self)
        source = {'scope': self.scope(), 'topics': [
            {'id': 1, 'query': 'ремонт квартиры', 'volume': 1000},
            {'id': 2, 'query': 'ремонт квартиры под ключ', 'volume': 100},
        ], 'verified_subsets': [{'child': 2, 'parent': 1, 'evidence': 'explicit-test-proof'}]}
        result = module.audit(source)
        self.assertEqual(result['demand'].get('upper_bound'), 1000)
        self.assertEqual(result['demand'].get('unique_total'), 1000)
        self.assertEqual(result['counts']['topics'], 2)
        self.assertEqual(len(result.get('topics', [])), 2)

    def test_invalid_evidence_cannot_remove_query_counts(self):
        module = load_module(self)
        import copy
        base = {'scope': self.scope(), 'topics': [
            {'id': 1, 'query': 'родитель', 'volume': 100},
            {'id': 2, 'query': 'дочерний', 'volume': 20},
        ]}
        cases = []
        for invalid in [-1, True, '20']:
            item = copy.deepcopy(base)
            item['topics'][1]['volume'] = invalid
            cases.append(item)
        for edges in [
            [{'child': 2, 'parent': 1}],
            [{'child': 2, 'parent': 99, 'evidence': 'proof'}],
            [{'child': 2, 'parent': 1, 'evidence': 'proof'}, {'child': 1, 'parent': 2, 'evidence': 'proof'}],
            [{'child': 1, 'parent': 2, 'evidence': 'proof'}],
        ]:
            item = copy.deepcopy(base)
            item['verified_subsets'] = edges
            cases.append(item)
        cases.append({'scope': self.scope(), 'topics': [
            {'id': 1, 'query': 'один запрос', 'volume': 100},
            {'id': 2, 'query': 'один запрос', 'volume': 100},
        ], 'verified_subsets': [{'child': 1, 'parent': 2, 'evidence': 'proof'}]})
        for item in cases:
            with self.subTest(item=item), self.assertRaises(ValueError):
                module.audit(item)

    def test_duplicate_query_is_counted_once_without_editing_source(self):
        module = load_module(self)
        source = {'scope': self.scope(), 'topics': [
            {'id': 1, 'query': 'Ремонт квартиры', 'volume': 100},
            {'id': 2, 'query': '  ремонт квартиры  ', 'volume': 100},
        ]}
        result = module.audit(source)
        self.assertEqual(result['demand'].get('upper_bound'), 100)
        self.assertEqual(result['topics'][1]['query'], '  ремонт квартиры  ')

    def test_cli_exports_source_rows_and_keeps_missing_distinct_from_zero(self):
        import csv
        import json
        import subprocess
        import sys
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'input.json'
            source.write_text(json.dumps({'scope': {}, 'topics': [
                {'id': 1, 'query': 'нулевая частота', 'volume': 0, 'title': 'Исходное название'},
                {'id': 2, 'query': 'нет частоты', 'volume': None},
            ]}, ensure_ascii=False))
            result = subprocess.run([sys.executable, str(MODULE), '--input', str(source),
                                     '--out', str(root / 'result')], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            output = root / 'result' / 'topics.csv'
            self.assertTrue(output.exists(), 'CLI должен создать таблицу тем')
            with output.open(encoding='utf-8-sig') as stream:
                rows = list(csv.DictReader(stream, delimiter=';'))
            self.assertEqual(rows[0]['volume'], '0')
            self.assertEqual(rows[1]['volume'], '')
            self.assertEqual(rows[0]['title'], 'Исходное название')
            report = json.loads((root / 'result' / 'audit.json').read_text())
            self.assertEqual(report['counts']['missing_volume'], 1)
            self.assertIn('needs_scope', report['topics'][0]['issues'])
            self.assertIn('needs_volume', report['topics'][1]['issues'])

    def test_different_measurement_scopes_cannot_be_combined(self):
        module = load_module(self)
        source = {'scope': self.scope(), 'topics': [
            {'id': 1, 'query': 'запрос один', 'volume': 100},
            {'id': 2, 'query': 'запрос два', 'volume': 20,
             'scope': {'region_id': '2'}},
        ]}
        with self.assertRaises(ValueError):
            module.audit(source)

    @staticmethod
    def scope():
        return {'region_id': '213', 'device': 'all', 'period_start': '2026-10-18',
                'period_end': '2026-11-16', 'frequency_type': 'broad',
                'measured_at': '2026-11-16', 'measurement_source': 'test-fixture'}


if __name__ == '__main__':
    unittest.main()
