#!/usr/bin/env python3
"""Инвентаризация семантики до запуска статей; публикацию не выполняет."""


REQUIRED_SCOPE = ('region_id', 'device', 'period_start', 'period_end',
                  'frequency_type', 'measured_at', 'measurement_source')


def audit(source):
    topics = source.get('topics', [])
    scope = source.get('scope', {})
    demand = {'status': 'unverified_scope', 'unique_total': None,
              'lower_bound': None, 'upper_bound': None}
    rows = {str(row['id']): row for row in topics}
    if len(rows) != len(topics):
        raise ValueError('Идентификаторы тем должны быть уникальными')
    for row in topics:
        row_scope = {**scope, **row.get('scope', {})}
        if any(row_scope.get(key) != scope.get(key) for key in REQUIRED_SCOPE):
            raise ValueError('Разные регионы, периоды или типы частоты: разделите срезы')
        value = row.get('volume')
        if value is not None and (type(value) is not int or value < 0):
            raise ValueError('Частотность должна быть целым неотрицательным числом или null')
    parents = {}
    for edge in source.get('verified_subsets', []):
        child, parent = str(edge['child']), str(edge['parent'])
        if not edge.get('evidence') or child not in rows or parent not in rows:
            raise ValueError('Для вложенности нужны существующие темы и основание')
        parents[child] = parent
        a, b = rows[child].get('volume'), rows[parent].get('volume')
        if a is not None and b is not None and a > b:
            raise ValueError('Частотность вложенного запроса превышает родительскую')
    for child in parents:
        seen, node = set(), child
        while node in parents:
            if node in seen:
                raise ValueError('Циклическая вложенность запросов')
            seen.add(node)
            node = parents[node]
    distinct = {}
    duplicate_ids = set()
    for row in topics:
        key = ' '.join(row['query'].casefold().split())
        if key in distinct:
            if distinct[key].get('volume') != row.get('volume'):
                raise ValueError('Один запрос имеет разные частотности в одном срезе')
            duplicate_ids.add(str(row['id']))
        else:
            distinct[key] = row
    covered = set(parents) | duplicate_ids
    if all(scope.get(k) for k in REQUIRED_SCOPE):
        values = [row['volume'] for row in topics if row.get('volume') is not None]
        roots = [row for row in topics if str(row['id']) not in covered]
        lower = max(values, default=0)
        upper = sum(row['volume'] for row in roots) if all(row.get('volume') is not None for row in topics) else None
        if upper is not None and upper < lower:
            raise ValueError('Связи вложенности и повторы противоречат границам спроса')
        demand.update(status='bounds_only', lower_bound=lower, upper_bound=upper,
                      unique_total=lower if lower == upper else None)
    checked = []
    for row in topics:
        issues = []
        if demand['status'] == 'unverified_scope':
            issues.append('needs_scope')
        if row.get('volume') is None:
            issues.append('needs_volume')
        issues.append('needs_serp_and_editorial_review')
        checked.append({**row, 'issues': issues})
    return {'counts': {'topics': len(topics), 'ready': 0,
                       'missing_volume': sum(row.get('volume') is None for row in topics)},
            'demand': demand, 'topics': checked}


def main():
    import argparse
    import csv
    import json
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    source = json.loads(Path(args.input).read_text(encoding='utf-8'))
    result = audit(source)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / 'audit.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    columns = ['id', 'rubric', 'title', 'query', 'volume', 'proposed_action', 'review_note', 'issues']
    with (out / 'topics.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, delimiter=';', extrasaction='ignore')
        writer.writeheader()
        for row in result['topics']:
            writer.writerow({**row, 'issues': ', '.join(row['issues'])})
    print(json.dumps({'counts': result['counts'], 'demand': result['demand'], 'output': str(out)}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
