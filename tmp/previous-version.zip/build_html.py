from pathlib import Path
import re
import base64

root = Path(__file__).parent
source = (root / 'docs/effect-combined-bold.html').read_text()
# Apply nonbreaking spaces only to visible text, never to code or attributes.
parts = re.split(r'(<style\b[^>]*>.*?</style>|<script\b[^>]*>.*?</script>|<[^>]+>)', source, flags=re.S | re.I)
short = re.compile(r'(?<![\w])(в|во|к|ко|с|со|у|о|об|на|за|по|до|из|от|и|а|но|не|при|без|для|над|под|про) +(?=[А-Яа-яЁёA-Za-z0-9])', re.I)
units = re.compile(r'(\d) +(₽|часа|часов|час|минут|мин|ч)(?![\w])', re.I)
for i, part in enumerate(parts):
    if not part.startswith('<'):
        parts[i] = units.sub(r'\1&nbsp;\2', short.sub(lambda m: m[1] + '&nbsp;', part))
result = ''.join(parts)
# Embed the single verified, self-hosted OFL font and its license notice.
font_count = 0
for family, filename in [('prata', 'Prata-Regular.ttf')]:
    data = (root / 'docs/fonts' / filename).read_bytes()
    encoded = 'data:font/ttf;base64,' + base64.b64encode(data).decode()
    relative_url = 'fonts/' + filename
    assert relative_url in result, relative_url
    result = result.replace(relative_url, encoded)
    license_text = (root / 'docs/fonts' / (family + '-OFL.txt')).read_text()
    result = result.replace('</html>', '\n<!--\n' + license_text + '\n-->\n</html>')
    font_count += 1
assert 'fonts.googleapis.com' not in result
out = root / 'docs/na24.html'
out.write_text(result)
print({'output': str(out), 'nbsp': result.count('&nbsp;'), 'embedded_fonts': font_count, 'bytes': out.stat().st_size})
