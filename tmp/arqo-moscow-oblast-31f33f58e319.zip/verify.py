from pathlib import Path
import json,re,subprocess,zipfile,io,csv
from PIL import Image
P=Path(__file__).resolve().parent
text=(P/'report.md').read_text();parts=text.split('<!--page-->');assert len(parts)==7
assert not re.search(r'Экономик|окупаемост|250\s?000|странице [67]|/designbureau|/newbuild',re.sub(r'<[^>]*>','',text),re.I)
assert 'Еженедельные отчёты по позициям страниц — в Telegram и на электронную почту.' in text
assert 'Ежемесячные сводки:' in text
assert 'Генерация иллюстраций входит в ведение' in text
assert 'не выдаём за реальные объекты' in text
D=json.loads((P/'regional-groups.json').read_text());G=D['groups'];assert len(G)==8
M=json.loads((P/'moscow-groups.json').read_text());assert len(M['groups'])==8
fmt=lambda n:f'{n:,}'.replace(',',' ')
for d,region in [(D,'1'),(M,'213')]:
 assert d['scope']['region']==region
 for i,g in enumerate(d['groups']):
  raw=json.loads((P/g['raw_file']).read_text());assert raw==g['measurement']
  assert raw['status']==200 and raw['request']['phrase']==g['query']
  assert raw['request']['regions']==[region] and raw['request']['devices']==['DEVICE_ALL']
  assert raw['collected_at'].startswith('2026-11-17')
  assert int(raw['response']['totalCount'])==g['volume']
  for word in g['excluded']:assert '-'+word in g['query']
  if i<6:
   assert 'ремонт' in g['query'].split(' -')[0]
   for earlier in d['groups'][:i]:assert earlier['anchor'] in g['excluded']
 assert 'ремонт' in d['groups'][6]['excluded']
 assert {'ремонт','дизайн'}.issubset(d['groups'][7]['excluded'])
for g,m in zip(G,M['groups']):
 assert g['query']==m['query'] and g['moscow_volume']==m['volume']
 assert f"| {g['name']} | {fmt(m['volume'])} | {fmt(g['volume'])} |" in parts[1]
B=sum(g['volume'] for g in G);assert B==23300
assert fmt(B) in parts[0] and fmt(B) in parts[5]
def walk(ns):
 for n in ns:
  yield n
  yield from walk(n.get('children',[]))
tree=json.loads((P/'regions-tree.json').read_text());r=next(n for n in walk(tree['regions']) if str(n['id'])=='1')
assert any(str(n['id'])=='213' for n in walk(r['children']))
F=json.loads((P/'forecast.json').read_text());assert F['base']==B and 'economics' not in F
for s in F['scenarios']:
 lo=B*s['coverage'][0]*s['ctr'][0];hi=B*s['coverage'][1]*s['ctr'][1]
 assert s['visits']==[lo,hi] and s['leads']==[lo*.01,hi*.02]
 row=f"| {s['month']} {'месяца' if s['month']==3 else 'месяцев'} | {s['coverage'][0]:.0%}–{s['coverage'][1]:.0%} | {fmt(round(lo))}–{fmt(round(hi))} | {lo*.01:.1f}–{hi*.02:.1f} |".replace('.',',')
 assert row in parts[5],row
rows=json.loads((P/'research.json').read_text())+json.loads((P/'enriched.json').read_text())
serps=[r for r in rows if r.get('docs')];assert len(serps)==16
assert all('arqoremont.ru' not in d['url'] for r in serps for d in r['docs'])
s=io.StringIO();w=csv.writer(s,delimiter=';');w.writerow(['Запрос','Позиция','URL','Регион','Дата'])
for r in serps:
 for d in r['docs']:w.writerow([r['query'],d['pos'],d['url'],'213','17.11.2026'])
(P/'search-slices.csv').write_text(s.getvalue(),encoding='utf-8-sig')
subprocess.run(['pdftotext','-layout',str(P/'arqo-niche-inwider.pdf'),str(P/'pdf-text.txt')],check=True)
pages=[x for x in (P/'pdf-text.txt').read_text().split('\f') if x.strip()];assert len(pages)==7
for i,p in enumerate(pages,1):
 assert all(v in p for v in ['Дмитрий Серый','inwider','Telegram @inwider','17.11.2026'])
 assert re.search(rf'{i}\s*/\s*7',p)
assert not re.search(r'Экономика|расчёт окупаемости|/designbureau|/newbuild', ''.join(pages),re.I)
assert '5. Прогноз' in pages[5] and '6. Наше предложение' in pages[6]
assert '23300' in re.sub(r'\s','',pages[0])
urls=subprocess.run(['pdfinfo','-url',str(P/'arqo-niche-inwider.pdf')],capture_output=True,text=True,check=True).stdout
assert urls.count('https://t.me/inwider')>=7
with zipfile.ZipFile(P/'arqo-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 names=['report.md','render.py','verify.py','regional-wordstat.csv','regional-groups.json','moscow-groups.json','regions-tree.json','measurement-method.md','search-slices.csv','forecast.json','research.json','enriched.json','extracted-live.json']
 for name in names:z.write(P/name,name)
 for directory in ['raw-region','raw-moscow']:
  for f in (P/directory).glob('*.json'):z.write(f,str(f.relative_to(P)))
summary={'verified':True,'groups':len(G),'base_moscow_and_oblast':B,'moscow_only':sum(g['volume'] for g in M['groups']),'pdf_pages':len(pages),'forecast_checked':True,'economics_removed':True,'regional_overlap_excluded':True,'reporting_checked':True,'footers_checked':True}
(P/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
subprocess.run(['pdftoppm','-scale-to','1100','-png',str(P/'arqo-niche-inwider.pdf'),str(P/'page')],check=True)
out=Image.new('RGB',(1596,4600),'#ddd')
for i,f in enumerate(sorted(P.glob('page-*.png'))):
 im=Image.open(f).convert('RGB');im.thumbnail((778,1100));out.paste(im,(15+(i%2)*798,15+(i//2)*1150))
out.save(P/'contact-sheet.jpg')
print(json.dumps(summary,ensure_ascii=False))
