from pathlib import Path
import json, markdown, subprocess, tempfile, threading, http.server, functools
P=Path(__file__).resolve().parent
css='''@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;color:#202124;font-family:Arial,"DejaVu Sans",sans-serif;font-size:10pt;line-height:1.42}section{width:210mm;height:297mm;padding:17mm 17mm 22mm;position:relative;break-after:page}section:last-child{break-after:auto}.eyebrow{font-size:8pt;color:#777;letter-spacing:1px;margin-bottom:9mm}h1{font-size:23pt;line-height:1.14;margin:0 0 7mm;letter-spacing:-.5px}h2{font-size:14pt;line-height:1.2;margin:6mm 0 3mm}p{margin:0 0 3mm}strong{font-weight:700}a{color:inherit;text-decoration:underline;text-underline-offset:2px}.subtitle{font-size:17pt;line-height:1.3;margin-bottom:5mm}.metrics{display:flex;gap:3mm;margin:7mm 0}.metrics>div{flex:1;border:1px solid #d9dcdf;padding:4mm}.metrics .alert{background:#fff4f3;border-color:#e9b9b4}.metrics strong{display:block;font-size:27pt;line-height:1.2;margin-bottom:2mm}.metrics span{display:block;font-size:8.5pt}.callout{background:#f5f6f7;border-left:3px solid #202124;padding:4mm;margin:4mm 0}.source{font-size:7.8pt;color:#696d73;line-height:1.35;margin:3mm 0}table{border-collapse:collapse;width:100%;font-size:9pt;margin:4mm 0}th{background:#eef1f3;font-weight:700}th,td{text-align:left;vertical-align:top;padding:2.2mm;border-bottom:1px solid #dfe2e5}tr{break-inside:avoid}ul{padding-left:5mm;margin:2mm 0 4mm}li{margin-bottom:2mm}footer{position:absolute;bottom:10mm;left:17mm;right:17mm;border-top:1px solid #d9dcdf;padding-top:3mm;display:flex;justify-content:space-between;gap:3mm;color:#6a6e73;font-size:7.4pt}.price{font-size:32pt;font-weight:700;margin:7mm 0}.price span{font-size:13pt;font-weight:400}.cover h1{font-size:29pt}.cover .source{margin-top:6mm}.dense{font-size:9.7pt}.dense table{font-size:8.8pt}.dense th,.dense td{padding:1.9mm}'''
parts=(P/'report.md').read_text().split('<!--page-->')
assert len(parts)==8
sections=[]
for i,part in enumerate(parts,1):
    body=markdown.markdown(part,extensions=['tables','sane_lists'])
    prefix='Подготовлено ' if i==1 else ''
    footer=f'{prefix}Дмитрий Серый - inwider - Telegram <a href="https://t.me/inwider">@inwider</a>'
    sections.append(f'<section class="{"cover" if i==1 else "dense"}" data-page="{i}"><div class="eyebrow">INWIDER · РАЗБОР НИШИ · ARQOREMONT.RU</div><main>{body}</main><footer><span>{footer}</span><span>17.11.2026 · {i} / {len(parts)}</span></footer></section>')
page='<!doctype html><html lang="ru"><meta charset="utf-8"><title>ARQO — разбор ниши — inwider</title><style>'+css+'</style><body>'+''.join(sections)+'</body></html>'
(P/'report.html').write_text(page)
probe='''<script>document.fonts.ready.then(()=>{document.body.dataset.layout=JSON.stringify([...document.querySelectorAll('section')].map(s=>({page:s.dataset.page,remaining:s.querySelector('footer').getBoundingClientRect().top-s.querySelector('main').getBoundingClientRect().bottom})))})</script>'''
(P/'probe.html').write_text(page+probe)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(P)))
threading.Thread(target=server.serve_forever,daemon=True).start()
try:
    import re,html
    with tempfile.TemporaryDirectory(dir='/home/hermes/.hermes/cache/scratch') as profile:
        cmd=['google-chrome','--headless=new','--no-sandbox','--disable-gpu','--user-data-dir='+profile]
        url=f'http://127.0.0.1:{server.server_port}/'
        r=subprocess.run(cmd+['--dump-dom','--virtual-time-budget=1500',url+'probe.html'],capture_output=True,text=True,timeout=60)
        m=re.search(r'data-layout="([^"]+)"',r.stdout);assert m,r.stderr
        layout=json.loads(html.unescape(m[1]));(P/'layout-checks.json').write_text(json.dumps(layout,indent=2));print(layout)
        assert all(x['remaining']>8 for x in layout),'Footer overlap'
        r=subprocess.run(cmd+['--no-pdf-header-footer','--print-to-pdf='+str(P/'arqo-niche-inwider.pdf'),url+'report.html'],capture_output=True,text=True,timeout=90)
        assert r.returncode==0,r.stderr
finally:
    server.shutdown()
print('PDF ready')
