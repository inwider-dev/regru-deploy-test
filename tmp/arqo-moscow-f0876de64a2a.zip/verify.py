from pathlib import Path
import json,csv,io,subprocess,zipfile,math,re
from PIL import Image
P=Path(__file__).resolve().parent
text=(P/'report.md').read_text();parts=text.split('<!--page-->');assert len(parts)==8
D=json.loads((P/'moscow-groups.json').read_text());G=D['groups'];assert len(G)==8
assert D['scope']['region']=='213' and D['scope']['devices']==['DEVICE_ALL']
for g in G:
 raw=json.loads((P/g['raw_file']).read_text());assert raw==g['measurement']
 assert raw['status']==200 and raw['request']['phrase']==g['query']
 assert raw['request']['regions']==['213'] and raw['request']['devices']==['DEVICE_ALL']
 assert raw['collected_at'].startswith('2026-11-17')
 assert int(raw['response']['totalCount'])==g['volume']
 for word in g['excluded']:assert '-'+word in g['query']
 assert f"| {g['name']} | {g['volume']:,}".replace(',',' ') in parts[1]
# First six groups all require repair; later groups exclude it.
for i,g in enumerate(G[:6]):
 assert 'ремонт' in g['query'].split(' -')[0]
 for earlier in G[:i]:assert earlier['anchor'] in g['excluded']
assert 'ремонт' in G[6]['excluded']
assert {'ремонт','дизайн'}.issubset(G[7]['excluded'])
B=sum(g['volume'] for g in G);F=json.loads((P/'forecast.json').read_text());assert F['base']==B
for s in F['scenarios']:
 lo=B*s['coverage'][0]*s['ctr'][0];hi=B*s['coverage'][1]*s['ctr'][1]
 assert s['visits']==[lo,hi]
 assert s['leads']==[lo*.01,hi*.02]
 row=f"| {s['month']} месяцев | {s['coverage'][0]:.0%}–{s['coverage'][1]:.0%} | {round(lo)}–{round(hi):,} | {lo*.01:.1f}–{hi*.02:.1f} |".replace(',',' ').replace('.',',')
 assert row in parts[5],row
E=F['economics'];assert E['monthly_fee']*12==E['annual_fee']==600000
for profit,expected in zip(E['contribution_examples'],[500,334,200]):
 visits=math.ceil(150000/profit/.2/.015-1e-9);assert visits==expected
assert 250000/50000==5 and 3*250000-600000==150000
assert 8*250000-600000==1400000 and 8*250000/600000>=3
assert E['annual_example_deals']/E['lead_to_deal']==E['annual_required_qualified_leads']==40
assert not re.search(r'фотографии с разрешением|предоставлен\w* клиент\w* фотограф|реальные фотографии',text,re.I)
assert 'Генерация иллюстраций входит в ведение' in text
assert 'не выдаём за реальные объекты' in text
rows=json.loads((P/'research.json').read_text())+json.loads((P/'enriched.json').read_text())
serps=[r for r in rows if r.get('docs')];assert len(serps)==16
assert all('arqoremont.ru' not in d['url'] for r in serps for d in r['docs'])
s=io.StringIO();w=csv.writer(s,delimiter=';');w.writerow(['Запрос','Позиция','URL','Регион','Дата'])
for r in serps:
 for d in r['docs']:w.writerow([r['query'],d['pos'],d['url'],'213','17.11.2026'])
(P/'search-slices.csv').write_text(s.getvalue(),encoding='utf-8-sig')
s=io.StringIO();w=csv.writer(s,delimiter=';');w.writerow(['Группа','Выражение Wordstat','Широкая частота с исключениями','Регион','Устройства','Дата'])
for g in G:w.writerow([g['name'],g['query'],g['volume'],'213','DEVICE_ALL',g['measurement']['collected_at']])
(P/'moscow-wordstat.csv').write_text(s.getvalue(),encoding='utf-8-sig')
subprocess.run(['pdftotext','-layout',str(P/'arqo-niche-inwider.pdf'),str(P/'pdf-text.txt')],check=True)
pages=[x for x in (P/'pdf-text.txt').read_text().split('\f') if x.strip()];assert len(pages)==8
for i,page in enumerate(pages,1):
 assert all(s in page for s in ['Дмитрий Серый','inwider','Telegram @inwider','17.11.2026']),i
 assert re.search(rf'{i}\s*/\s*8',page),i
urls=subprocess.run(['pdfinfo','-url',str(P/'arqo-niche-inwider.pdf')],capture_output=True,text=True,check=True).stdout
assert urls.count('https://t.me/inwider')>=8
with zipfile.ZipFile(P/'arqo-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['report.md','render.py','moscow-wordstat.csv','moscow-groups.json','measurement-method.md','search-slices.csv','forecast.json','research.json','enriched.json','extracted-live.json']+[x.name for x in P.glob('brand*.json')]:z.write(P/name,name)
 for g in G:z.write(P/g['raw_file'],g['raw_file'])
 z.write(P/'verify.py','verify.py')
(P/'verification.json').write_text(json.dumps({'moscow_groups_verified':len(G),'base':B,'nonbrand_queries':len(serps),'pdf_pages':len(pages),'all_footers_verified':True,'operators_checked':True,'economics_checked':True,'forecast_checked':True},ensure_ascii=False,indent=2))
subprocess.run(['pdftoppm','-scale-to','1100','-png',str(P/'arqo-niche-inwider.pdf'),str(P/'page')],check=True)
out=Image.new('RGB',(1596,4600),'#ddd')
for i,path in enumerate(sorted(P.glob('page-*.png'))):
 im=Image.open(path).convert('RGB');im.thumbnail((778,1100));out.paste(im,(15+(i%2)*798,15+(i//2)*1150))
out.save(P/'contact-sheet.jpg')
print(json.dumps({'verified':True,'groups':len(G),'base':B,'pdf_pages':len(pages),'forecast':F['scenarios']},ensure_ascii=False))
